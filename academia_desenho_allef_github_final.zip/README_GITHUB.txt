ACADEMIA DE DESENHO ALLEF — PACOTE GITHUB PAGES

Arquivo principal:
- index.html

Arquivos auxiliares:
- robots.txt
- sitemap.xml

COMO ENVIAR
1. Abra o repositório no GitHub.
2. Vá em Code.
3. Escolha Upload files.
4. Envie index.html (este é o arquivo principal).
5. Você também pode enviar robots.txt e sitemap.xml.
6. Deixe "Commit directly to the main branch" marcado.
7. Toque em Commit changes.
8. Aguarde o GitHub Pages publicar a atualização.

IMPORTANTE
- O arquivo principal DEVE se chamar exatamente index.html.
- Não envie index-13.html como página principal.
