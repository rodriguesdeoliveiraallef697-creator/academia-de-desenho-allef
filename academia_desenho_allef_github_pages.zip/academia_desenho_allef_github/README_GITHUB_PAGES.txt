ACADEMIA DE DESENHO ALLEF — GITHUB PAGES

Pacote preparado para publicação como site estático.

ARQUIVOS
- index.html — página principal do curso
- robots.txt — orientação para mecanismos de busca
- sitemap.xml — mapa básico do site

PUBLICAÇÃO
1. Crie um repositório público no GitHub.
2. Envie os três arquivos para a raiz do repositório.
3. Vá em Settings > Pages.
4. Em Build and deployment, selecione Deploy from a branch.
5. Escolha a branch main e a pasta /(root).
6. Salve e aguarde a publicação.

IMPORTANTE
- Substitua SEUUSUARIO em sitemap.xml pelo seu nome de usuário do GitHub.
- O endereço final normalmente será:
  https://SEUUSUARIO.github.io/academia-de-desenho-allef/
- HTTPS deve permanecer ativado quando disponível.
- Depois da publicação, cadastre o endereço no Google Search Console e solicite indexação.

Este pacote não contém credenciais ou senhas.
